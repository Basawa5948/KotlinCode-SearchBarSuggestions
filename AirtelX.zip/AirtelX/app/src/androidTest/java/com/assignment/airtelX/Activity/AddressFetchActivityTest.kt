package com.assignment.airtelX.Activity

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.typeText
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.rule.ActivityTestRule
import com.assignment.airtelX.R
import org.junit.Rule
import org.junit.Test


class AddressFetchActivityTest {

    @Rule
    @JvmField
    var activityRule = ActivityTestRule<AddressFetchActivity>(
        AddressFetchActivity::class.java
    )

    @Test
    @Throws(Exception::class)
    fun cityNameEditText() {
        onView(withId(R.id.city)).perform(click());
        onView(withId(R.id.city)).perform(typeText("gurgaon"));
    }

    @Test
    @Throws(Exception::class)
    fun queryStringEditText() {
        onView(withId(R.id.query)).perform(click());
        onView(withId(R.id.query)).perform(typeText("airtel"));
    }
}
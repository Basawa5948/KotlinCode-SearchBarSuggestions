package com.assignment.airtelX.Presenter

interface ActivityListener {
    fun onViewUpdated(addressListValues: ArrayList<String>);
    fun onError(s: String);
}
package com.assignment.airtelX.Activity

import android.content.Context
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.assignment.airtelX.AdapterManager.AddressListAdapter
import com.assignment.airtelX.Presenter.ActivityListener
import com.assignment.airtelX.Presenter.ViewModelPresenter
import com.assignment.airtelX.R
import kotlin.collections.ArrayList

class AddressFetchActivity : AppCompatActivity(),ActivityListener {

    var textWatcher:TextWatcher?=null

    lateinit var cityName:String
    lateinit var queryString:String
    lateinit var editCityName:EditText
    lateinit var editQueryString:EditText
    lateinit var recyclerView:RecyclerView
    lateinit var addressListValues:ArrayList<String>

    var mViewModel: ViewModelPresenter? = null
    var mActivityListener: ActivityListener? = null
    var mAddressAdapter:AddressListAdapter = AddressListAdapter(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.address_fetch)
        init();
    }

    private fun init() {
        addressListValues = ArrayList()
        mActivityListener = this

        editCityName = findViewById(R.id.city) as EditText
        editQueryString = findViewById(R.id.query) as EditText
        recyclerView = findViewById(R.id.recyclreView) as RecyclerView

        recyclerView.setHasFixedSize(true)
        recyclerView.setItemViewCacheSize(20)
        val linearLayoutManager = LinearLayoutManager(this)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerView.layoutManager = linearLayoutManager
        recyclerView.isNestedScrollingEnabled = true
        recyclerView.setHasFixedSize(true)

        watchTextChange()

        editCityName.addTextChangedListener(textWatcher)
        editQueryString.addTextChangedListener(textWatcher)
    }

    private fun watchTextChange() {
        textWatcher = object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                cityName = editCityName.text.toString().trim()
                queryString = editQueryString.text.toString().trim()
                initiateRequest()
                cityName=""
                queryString=""
            }

            override fun afterTextChanged(p0: Editable?) {
                addressListValues.clear()
                mAddressAdapter.notifyDataSetChanged()
            }
        }
    }

    fun initiateRequest() {
        if(isOnline()) {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            )
            mViewModel = ViewModelPresenter();
            mViewModel?.getRequestData(cityName, queryString, mActivityListener)
        }
        else
            Toast.makeText(this@AddressFetchActivity,"No Internet Connection",Toast.LENGTH_LONG).show()
    }

    override fun onViewUpdated(addressListValues: ArrayList<String>) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        this.addressListValues = addressListValues
        mAddressAdapter = AddressListAdapter(addressListValues,this)
        recyclerView.adapter = mAddressAdapter
    }

    override fun onError(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    fun isOnline(): Boolean {
        val connectivityManager = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }
}

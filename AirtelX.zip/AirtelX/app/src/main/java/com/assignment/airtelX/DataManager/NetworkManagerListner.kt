package com.assignment.airtelX.DataManager

interface NetworkManagerListner {
    fun onSuccessResponse(response: String)
    fun onErrorResponse(message: String?)
}
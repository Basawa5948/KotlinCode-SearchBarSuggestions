package com.assignment.airtelX.AdapterManager

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.assignment.airtelX.R
import java.util.ArrayList

class AddressListAdapter : RecyclerView.Adapter<AddressListAdapter.ViewHolder> {

    var arrayList: ArrayList<String>? = null
    var context: Context? = null

    constructor(context: Context) {
        this.context = context
    }

    constructor(arrayList: ArrayList<String>, context: Context) {
        this.arrayList = arrayList
        this.context = context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(
            R.layout.list_items,
            parent, false
        )

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView.setText(arrayList!![position])
    }

    override fun getItemCount(): Int {
        return arrayList!!.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        internal var textView: TextView

        init {

            textView = itemView.findViewById(R.id.address_list) as TextView

        }
    }
}
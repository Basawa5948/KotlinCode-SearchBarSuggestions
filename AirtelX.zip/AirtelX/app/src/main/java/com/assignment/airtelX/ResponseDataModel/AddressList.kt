package com.assignment.airtelX.ResponseDataModel

class AddressList {

    var addressString: String? = null

}
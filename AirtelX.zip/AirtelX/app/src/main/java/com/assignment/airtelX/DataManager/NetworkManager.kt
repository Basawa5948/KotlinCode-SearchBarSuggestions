package com.assignment.airtelX.DataManager

import android.os.Environment
import android.util.Log
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.BasicNetwork
import com.android.volley.toolbox.DiskBasedCache
import com.android.volley.toolbox.HurlStack
import com.android.volley.toolbox.StringRequest
import com.assignment.airtelX.Presenter.ViewModelPresenter

class NetworkManager {

    lateinit var cityName:String
    lateinit var queryString:String
    lateinit var networkManagerListner: NetworkManagerListner
    var URL:String = "https://digi-api.airtel.in/compassLocation/rest/address/autocomplete?"
    val QUERY = "queryString="
    val CITY = "city="
    val CONST = "&"

    fun makeRequest(cityName: String, queryString: String, networkManagerListner: ViewModelPresenter) {
        this.cityName = cityName
        this.queryString = queryString
        this.networkManagerListner = networkManagerListner
        URL = URL+QUERY+queryString+CONST+CITY+cityName

        processRequest()
    }

    private fun processRequest() {
        val cache = DiskBasedCache(Environment.getRootDirectory(), 1024 * 1024)
        val network = BasicNetwork(HurlStack())
        val requestQueue = RequestQueue(cache, network).apply {
            start()
        }

        val stringRequest = StringRequest(
            Request.Method.GET, URL,
            Response.Listener<String> { response ->
                Log.d("SUCCESS RESPONSE",response)
                networkManagerListner.onSuccessResponse(response)
            },
            Response.ErrorListener { error ->
                Log.d("ERROR RESPONSE",error.message)
                networkManagerListner.onErrorResponse(error.message)
            })
        requestQueue.add(stringRequest)
    }
}
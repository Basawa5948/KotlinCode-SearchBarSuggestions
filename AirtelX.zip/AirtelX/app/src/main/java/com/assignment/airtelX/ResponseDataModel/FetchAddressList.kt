package com.assignment.airtelX.ResponseDataModel

class FetchAddressList {

    var requestId: String? = null
    var data: FetchDataList? = null

}

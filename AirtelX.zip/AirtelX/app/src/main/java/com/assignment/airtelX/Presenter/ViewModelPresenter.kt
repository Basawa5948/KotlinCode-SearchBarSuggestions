package com.assignment.airtelX.Presenter

import com.assignment.airtelX.DataManager.NetworkManager
import com.assignment.airtelX.DataManager.NetworkManagerListner
import com.assignment.airtelX.ResponseDataModel.FetchAddressList
import com.google.gson.GsonBuilder

class ViewModelPresenter:NetworkManagerListner {

    lateinit var cityName:String
    lateinit var queryString:String
    lateinit var listener:ActivityListener
    lateinit var responseString: String
    lateinit var addressListValues:ArrayList<String>

    var responseModelList: FetchAddressList?=null
    var networkManagerListner: NetworkManagerListner? = null
    var networkManager: NetworkManager? = null


    fun getRequestData(cityName: String, queryString: String, param: ActivityListener?) {
        this.cityName = cityName
        this.queryString = queryString
        this.listener = param!!
        makeNetworkCall()
    }

    private fun makeNetworkCall() {
        networkManagerListner = this
        addressListValues = ArrayList()
        networkManager = NetworkManager();
        networkManager?.makeRequest(cityName,queryString, networkManagerListner as ViewModelPresenter)
    }

    override fun onSuccessResponse(response: String) {
        responseString = response
        val gson = GsonBuilder().create()
        responseModelList = gson.fromJson(responseString,FetchAddressList::class.java)
        for (i in 0 until responseModelList!!.data!!.addressList!!.size) {
            addressListValues.add(responseModelList!!.data!!.addressList!![i].addressString.toString())
        }
        listener.onViewUpdated(addressListValues)
    }

    override fun onErrorResponse(message: String?) {
        listener.onError("No Match Found")
    }
}
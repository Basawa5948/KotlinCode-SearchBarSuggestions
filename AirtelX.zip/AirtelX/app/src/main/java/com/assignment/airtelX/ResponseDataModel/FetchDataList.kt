package com.assignment.airtelX.ResponseDataModel

class FetchDataList {

    var addressList: List<AddressList>? = null

}